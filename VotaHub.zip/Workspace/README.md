# Sistema de Votação sobre Linguagens de Programação

Um banco de dados SQL simples para gerenciar um sistema de votação sobre preferência de linguagens de programação.

## Descrição do Projeto

Este projeto implementa um **sistema de votação completo** com:
- 🗄️ **Banco de dados SQL** para armazenar votos
- 🎨 **Interface web** minimalista e responsiva
- ⚡ **Lógica JavaScript** interativa

Usuários podem responder à pergunta: **"Qual linguagem você prefere?"**

### Opções de Voto
- JavaScript
- Python
- Java
- C#

## Estrutura do Banco de Dados

### Banco de Dados
- **Nome**: `votacao`
- **Compatibilidade**: MySQL

### Tabela: `votos`

| Coluna | Tipo | Descrição |
|--------|------|-----------|
| `id` | INT (PK, Auto-increment) | Identificador único de cada voto |
| `linguagem` | VARCHAR(50) | Linguagem escolhida pelo usuário |
| `data_voto` | TIMESTAMP | Data e hora do voto (automático) |

## Conteúdo do Script SQL

O arquivo `votacao_schema.sql` contém:

1. **Criação do Banco de Dados**
   - Drop (se existir) e criação do banco `votacao`

2. **Criação da Tabela**
   - Tabela `votos` com colunas necessárias
   - Chave primária com auto-incremento

3. **Dados de Exemplo**
   - 12 inserções de votos para teste

4. **Consultas de Análise**
   - Contagem de votos por linguagem
   - Identificação da linguagem mais votada

5. **Consultas Adicionais (Comentadas)**
   - Listagem completa de votos
   - Total de votos
   - Votos agrupados por data

## Como Usar

### 1. Executar o Script

No MySQL, use um dos seguintes métodos:

**Método 1: Linha de comando**
```bash
mysql -u seu_usuario -p < database/votacao_schema.sql
```

**Método 2: MySQL Workbench**
- Abra o arquivo `votacao_schema.sql`
- Clique em "Execute" ou pressione `Ctrl+Shift+Enter`

**Método 3: CLI MySQL interativo**
```bash
mysql -u seu_usuario -p
mysql> source database/votacao_schema.sql;
```

### 2. Visualizar Resultados

Após executar o script, as consultas retornarão:

**Contagem de Votos por Linguagem:**
```
linguagem    | total_votos
-------------|-------------
JavaScript   | 4
Python       | 4
Java         | 2
C#           | 2
```

**Linguagem Mais Votada:**
```
linguagem    | total_votos
-------------|-------------
JavaScript   | 4
```

## Inserir Novos Votos

Para adicionar novos votos ao sistema:

```sql
INSERT INTO votos (linguagem) VALUES ('JavaScript');
```

Substitua 'JavaScript' pela linguagem desejada.

## Exemplos de Consultas Úteis

### Contar Total de Votos
```sql
SELECT COUNT(*) AS total_votos FROM votos;
```

### Listar Todos os Votos com Data
```sql
SELECT * FROM votos ORDER BY data_voto DESC;
```

### Votos Recebidos Hoje
```sql
SELECT linguagem, COUNT(*) AS votos_hoje
FROM votos
WHERE DATE(data_voto) = CURDATE()
GROUP BY linguagem;
```

### Percentual de Votos
```sql
SELECT 
    linguagem,
    COUNT(*) AS votos,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM votos), 2) AS percentual
FROM votos
GROUP BY linguagem
ORDER BY votos DESC;
```

## Requisitos

- MySQL 5.7+
- Cliente MySQL (mysql-cli, MySQL Workbench, etc.)

## Estrutura de Pastas

```
.
├── .github/
│   └── copilot-instructions.md    # Instruções customizadas
├── database/
│   └── votacao_schema.sql         # Script SQL completo
├── web/
│   ├── index.html                 # Interface HTML
│   ├── styles.css                 # Estilos CSS minimalista
│   └── script.js                  # Lógica JavaScript
└── README.md                       # Este arquivo
```

## Interface Web

A interface web está localizada na pasta `web/` e oferece um **sistema de votação completo e personalizável**:

### Arquivos

- **index.html** - Estrutura HTML semântica com suporte a cenários dinâmicos
- **styles.css** - Design minimalista com cores neutras e variáveis CSS
- **script.js** - Lógica JavaScript com gerenciamento de múltiplos cenários

### Características

✓ **Design Minimalista** - Interface limpa com cores neutras (branco, cinza, tons de preto)
✓ **Cenários Personalizados** - Crie votações com perguntas e opções customizadas
✓ **Sem Limites de Opções** - Adicione quantas opções quiser (mínimo 2)
✓ **Persistência Local** - Dados salvos automaticamente no navegador
✓ **Responsivo** - Funciona em todos os tamanhos de tela
✓ **Acessível** - Semântica HTML correta
✓ **Sem Dependências** - Apenas HTML/CSS/JavaScript puro

### Funcionalidades

#### 1. Criar Novo Cenário
- Digite uma pergunta personalizada
- Adicione as opções de votação desejadas
- Sistema salva automaticamente no localStorage

#### 2. Gerenciar Cenários
- Visualize todos os cenários criados
- Veja o número de opções e total de votos
- Selecione qualquer cenário para votação
- **Botão × para excluir cenários** (com confirmação)

#### 3. Sistema de Votação
- Interface intuitiva com células clicáveis
- Feedback visual imediato
- Animações suaves
- **Botão 🔄 Zerar** - reseta todos os votos do cenário atual
- **Botão 🏁 Encerrar** - encerra a votação

#### 4. Análise de Resultados
- Barras de progresso com percentuais
- Contagem de votos por opção
- Total de votos em tempo real

#### 5. Sistema de Desempate Automático** ⭐
- Detecta automaticamente empates na votação
- Se houver empate, exibe um modal alertando as opções empatadas
- **Inicia automaticamente um segundo turno** com apenas as opções empatadas
- Os cenários de segundo turno são claramente identificados (🔄 Segundo Turno)
- Permite pular o segundo turno se desejar

### Como Usar

1. **Abra a interface:**
   - Duplo clique em `web/index.html` ou arraste para o navegador

2. **Crie um novo cenário:**
   - Clique na aba "+ Novo Cenário"
   - Digite a pergunta (ex: "Qual framework você prefere?")
   - Adicione opções (mínimo 2)
   - Clique "+ Adicionar Opção" para mais opções
   - Clique em "Criar Cenário"

3. **Vote:**
   - Acesse "Cenários Salvos"
   - Selecione o cenário desejado
   - Clique em uma opção
   - Clique em "Enviar Voto"

4. **Gerencie a votação:**
   - **🔄 Zerar**: Reseta todos os votos do cenário atual
   - **🏁 Encerrar**: Finaliza a votação e mostra resultados
   - **×**: Clique no botão de cada cenário para excluir

5. **Sistema de Desempate:**
   - Se ao clicar "Encerrar" houver empate, um modal aparecerá
   - Clique "Iniciar Segundo Turno" para continuar com as opções empatadas
   - O novo turno será criado automaticamente com apenas essas opções
   - Os votos do segundo turno começam zerados

6. **Veja resultados:**
   - Os resultados aparecem automaticamente abaixo
   - Atualizam em tempo real com cada voto

### Customização

#### Cores
Edite as variáveis CSS no arquivo `styles.css`:

```css
:root {
    /* Cores Principais */
    --color-white: #ffffff;
    --color-light-gray: #f5f5f5;
    --color-black: #212121;
    
    /* Cores de Acentuação */
    --color-accent: #757575;
    --color-accent-dark: #424242;
    
    /* Espaçamento */
    --spacing-sm: 1rem;
    --spacing-md: 1.5rem;
    --spacing-lg: 2rem;
}
```

#### Modo Escuro
Descomente a seção `@media (prefers-color-scheme: dark)` no final do `styles.css`

### Armazenamento de Dados

- Todos os cenários e votos são salvos no **localStorage** do navegador
- Dados persistem automaticamente
- Acessível em: `localStorage.getItem('votationScenarios')`

Para limpar todos os dados:
```javascript
localStorage.clear()
```

### Exemplo de Cenários

**Exemplo 1: Linguagens de Programação**
```
Pergunta: Qual linguagem você prefere?
Opções: JavaScript, Python, Java, C#, Go, Rust
```

**Exemplo 2: Frameworks Frontend**
```
Pergunta: Qual framework você usa?
Opções: React, Vue.js, Angular, Svelte
```

**Exemplo 3: Metodologias Ágeis**
```
Pergunta: Qual metodologia sua equipe usa?
Opções: Scrum, Kanban, XP, Hybrid
```

## Notas Importantes

- O script é totalmente compatível com MySQL
- A coluna `data_voto` registra automaticamente a data/hora de cada votação
- A tabela inclui um campo TIMESTAMP para auditoria de votos
- O script cria múltiplos índices e tabelas comentadas para fins educacionais

## Melhorias Futuras

Possíveis extensões do projeto:

- Adicionar tabela de usuários (email, nome, IP)
- Implementar limite de votos por usuário
- Adicionar categorias/períodos de votação
- Criar relatórios por região ou usuário
- Implementar validações de dados entrada

---

**Autor**: Sistema de Votação SQL  
**Compatibilidade**: MySQL 5.7+  
**Data de Criação**: 2026
