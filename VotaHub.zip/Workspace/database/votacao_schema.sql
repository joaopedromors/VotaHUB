-- ============================================================================
-- SISTEMA DE VOTAÇÃO SOBRE LINGUAGENS DE PROGRAMAÇÃO
-- Script SQL para MySQL
-- ============================================================================

-- ============================================================================
-- 1. CRIAR BANCO DE DADOS
-- ============================================================================

-- Verifica se o banco de dados já existe e o remove para começar do zero (opcional)
DROP DATABASE IF EXISTS votacao;

-- Cria o banco de dados chamado "votacao"
CREATE DATABASE votacao;

-- Seleciona o banco de dados para usar
USE votacao;

-- ============================================================================
-- 2. CRIAR TABELA DE VOTOS
-- ============================================================================

-- Cria a tabela "votos" com as colunas necessárias
CREATE TABLE votos (
    id INT AUTO_INCREMENT PRIMARY KEY,              -- ID único para cada voto (chave primária, auto incremento)
    linguagem VARCHAR(50) NOT NULL,                 -- Campo de texto para armazenar a linguagem escolhida
    data_voto TIMESTAMP DEFAULT CURRENT_TIMESTAMP   -- Registra a data e hora de cada voto (opcional)
);

-- ============================================================================
-- 3. EXEMPLOS DE INSERÇÃO DE VOTOS
-- ============================================================================

-- Insere votos de exemplo
INSERT INTO votos (linguagem) VALUES ('JavaScript');
INSERT INTO votos (linguagem) VALUES ('Python');
INSERT INTO votos (linguagem) VALUES ('JavaScript');
INSERT INTO votos (linguagem) VALUES ('Java');
INSERT INTO votos (linguagem) VALUES ('Python');
INSERT INTO votos (linguagem) VALUES ('C#');
INSERT INTO votos (linguagem) VALUES ('JavaScript');
INSERT INTO votos (linguagem) VALUES ('Python');
INSERT INTO votos (linguagem) VALUES ('Java');
INSERT INTO votos (linguagem) VALUES ('JavaScript');
INSERT INTO votos (linguagem) VALUES ('Python');
INSERT INTO votos (linguagem) VALUES ('C#');

-- ============================================================================
-- 4. CONSULTA PARA CONTAR VOTOS POR LINGUAGEM
-- ============================================================================

-- Conta quantos votos cada linguagem recebeu
-- Resultado ordenado em ordem decrescente de votos
SELECT 
    linguagem,                              -- Nome da linguagem
    COUNT(*) AS total_votos                 -- Quantidade de votos
FROM votos                                  -- Tabela de origem
GROUP BY linguagem                          -- Agrupa por linguagem
ORDER BY total_votos DESC;                  -- Ordena por maior número de votos

-- ============================================================================
-- 5. CONSULTA PARA MOSTRAR A LINGUAGEM MAIS VOTADA
-- ============================================================================

-- Encontra qual linguagem recebeu o maior número de votos
-- Usa uma subconsulta para encontrar o máximo de votos
SELECT 
    linguagem,                              -- Nome da linguagem mais votada
    COUNT(*) AS total_votos                 -- Total de votos dessa linguagem
FROM votos                                  -- Tabela de origem
GROUP BY linguagem                          -- Agrupa por linguagem
ORDER BY total_votos DESC                   -- Ordena por maior número de votos
LIMIT 1;                                    -- Retorna apenas o primeiro resultado (a mais votada)

-- ============================================================================
-- CONSULTAS ADICIONAIS (OPCIONAIS)
-- ============================================================================

-- Mostra todos os votos registrados
-- SELECT * FROM votos;

-- Mostra o total de votos no período
-- SELECT COUNT(*) AS total_de_votos FROM votos;

-- Mostra votos agrupados por data
-- SELECT DATE(data_voto) AS data, linguagem, COUNT(*) AS votos
-- FROM votos
-- GROUP BY DATE(data_voto), linguagem
-- ORDER BY data DESC;
