<!-- Instruções customizadas para o Copilot neste workspace -->

## SQL Voting System Database Project

Projeto de banco de dados SQL para um sistema simples de votação sobre linguagens de programação.

### Requisitos do Projeto
- Criar um script SQL compatível com MySQL
- Sistema de votação para 4 linguagens: JavaScript, Python, Java, C#
- Banco de dados "votacao" com tabela "votos"
- Consultas para análise de votos

### Estrutura do Projeto
- `database/` - Scripts SQL do banco de dados
- `README.md` - Documentação do projeto
